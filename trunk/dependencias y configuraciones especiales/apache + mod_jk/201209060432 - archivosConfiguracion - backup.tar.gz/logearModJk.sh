#!/bin/bash

echo "logearModJk.sh"

tail -f /etc/apache2/logs/mod_jk.log
