#!/bin/bash

echo "terracottaDevConsole.sh"

JAVA_HOME=/usr/lib/jvm/default-java /opt/terracotta-3.6.0/bin/dev-console.sh
