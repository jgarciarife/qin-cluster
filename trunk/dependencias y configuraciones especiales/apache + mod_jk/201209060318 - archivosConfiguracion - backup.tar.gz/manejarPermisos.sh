#!/bin/bash

echo "manejarPermisos.sh"

echo "sudo chmod 777 -R /etc/apache2"
sudo chmod 777 -R /etc/apache2
echo "sudo chmod 777 -R /etc/libapache2-mod-jk"
sudo chmod 777 -R /etc/libapache2-mod-jk
echo "sudo chmod 777 -R /opt/jboss-6.1.0.Final"
sudo chmod 777 -R /opt/jboss-6.1.0.Final
echo "sudo chmod 777 -R /opt/jboss-6.1.0.Final.2"
sudo chmod 777 -R /opt/jboss-6.1.0.Final.2
echo "sudo chmod 777 -R /opt/jboss-6.1.0.Final.3"
sudo chmod 777 -R /opt/jboss-6.1.0.Final.3
echo "sudo chmod 777 -R /opt/apache-tomcat-7.0.23"
sudo chmod 777 -R /opt/apache-tomcat-7.0.23
echo "sudo chmod 777 -R /opt/apache-tomcat-7.0.23.2"
sudo chmod 777 -R /opt/apache-tomcat-7.0.23.2
echo "sudo chmod 777 -R /opt/apache-tomcat-7.0.23.3"
sudo chmod 777 -R /opt/apache-tomcat-7.0.23.3
echo "sudo chmod 777 -R /opt/terracotta-3.6.0"
sudo chmod 777 -R /opt/terracotta-3.6.0
echo "sudo chmod 777 -R $HOME/terracotta 2> /dev/null"
sudo chmod 777 -R $HOME/terracotta 2> /dev/null
echo "sudo chmod 777 -R $HOME/workspace/qin-cluster/qin jboss sin ejb spring transactions"
sudo chmod 777 -R "$HOME/workspace/qin-cluster/qin jboss sin ejb spring transactions"
