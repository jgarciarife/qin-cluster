#!/bin/bash

echo "logearTerracotta.sh"

tail -f ALGO

