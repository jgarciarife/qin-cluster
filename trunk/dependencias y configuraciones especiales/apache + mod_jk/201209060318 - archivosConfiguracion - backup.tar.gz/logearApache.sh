#!/bin/bash

echo "logearApache.sh"

tail -f /var/log/apache2/error.log

